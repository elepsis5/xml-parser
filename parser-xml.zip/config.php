<?php
/**
 * Даныые для поключения к бд
 *
 * Php version 8.1.5

 * @category Components
 * @package  Parser
 * @author   Глобенко Игорь Валентинович <elepsis@bk.ru>
 * @license  https://github.com/elepsis5 My gitHub
 * @link     https://github.com/elepsis5/xml-parser.git
 * @since    0.1.0.0
 */
define('HOST', 'localhost');
define('DB_NAME', 'parser_db');
define('USER', 'root');
define('PASS', '');